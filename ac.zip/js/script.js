var i=0,Timer;
$(document).ready(function() {
	$('nav > ul > li').hover(function() {
		var index=$(this).index('nav > ul > li');
		$('nav > ul > li > ul').eq(index).slideToggle();
	});

	$('.slide').click(function() {
		$('header > nav').slideToggle();
		$('.slide').toggleClass('change');

	});

    Interval();

	$('.toggle>span').click(function() {
		clearInterval(Timer);
		i=$(this).index('.toggle>span');
		bannerShow();
	});

	function Interval() {
		var Timer=setInterval(function() {
			i++;
			if (i==3) {
				i=0;
			}
			$('.banner-text').eq(i).addClass('show').siblings().removeClass('show');
			$('.toggle>span').eq(i).addClass('active').siblings().removeClass('active');
			$('.banner-text > .banner_text').eq(i).addClass('banner-text_h1').siblings().removeClass('banner-text_h1');
		},3000)
	}

	function bannerShow() {
		$('.banner-text').eq(i).addClass('show').siblings().removeClass('show');
		$('.toggle>span').eq(i).addClass('active').siblings().removeClass('active');
		$('.banner-text > .banner_text').eq(i).addClass('banner-text_h1').siblings().removeClass('banner-text_h1');
	}

	window.onscroll=function() {
		if (document.documentElement.scrollTop > 20) {
			$('header').css({background:'rgba(0,0,0,0.5)'})
		}else {
			$('header').css({background:'rgba(0,0,0,0.1)'})
		}
	}
});

$(window).resize(function() {
	$('.slide').removeClass('change');
	var w=$(window).width();
	if (w>801) {
		$('header > nav').css({display:'block'});
	}else {
		$('header > nav').css({display:'none'});
	}

	var news_height = $('.news-left').innerHeight();
	var left_text = $('.news-left>div').innerHeight();
	console.log(news_height);
	console.log(left_text);
	var count = news_height - left_text;
	var childWidth = count/2;
	$('.news-left>div').css({paddingTop:childWidth+'px'});
	console.log(childWidth);

});

$(window).scroll(function() {
	if ($('html,body').scrollTop() > 20) {
		$('.arrow').css({display:'block'});
	}else {
		$('.arrow').css({display:'none'});
	}
});