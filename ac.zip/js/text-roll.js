// 声明
// 
// 
// 滚动的父元素的高度需要等于滚动元素的高度
// 滚动的父元素的高度需要等于滚动元素的高度
// 滚动的父元素的高度需要等于滚动元素的高度

// 获取需要滚动的元素
var roll = document.getElementById('roll');
var roll_one = document.getElementById('roll-one');
var roll_two = document.getElementById('roll-two');

roll.scrollTop = 0;

// 克隆roll_one给roll_two

roll_two.innerHTML = roll_one.innerHTML;

function myScroll() {
    if(roll.scrollTop >= roll_one.scrollHeight) {
        roll.scrollTop = 0;
    }else {
        roll.scrollTop++;
    }
}

var time = 50;

var interval = setInterval('myScroll()', time);

roll.onmouseover = function () {
    clearInterval(interval);
};

roll.onmouseout = function () {
    // 继续执行之前的定时器
    interval = setInterval('myScroll()', time);
};